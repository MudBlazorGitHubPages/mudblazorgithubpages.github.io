self.assetsManifest = {
  "version": "Gbvj4vBc",
  "assets": [
    {
      "hash": "sha256-47DEQpj8HBSa+/TImW+5JCeuQeRkm5NMpJWZG3hSuFU=",
      "url": ".nojekyll"
    },
    {
      "hash": "sha256-Ps2EqpQtAHIfcMzWG8A9KuCME6yn86porJbKiOVBYYc=",
      "url": "404.html"
    },
    {
      "hash": "sha256-poV4ELCt5FQ5ItXigsTvFDRnFsaBxnHpwAAXEZ0ho7k=",
      "url": "MudBlazorGitHubPages.styles.css"
    },
    {
      "hash": "sha256-UVy3L6kXaa89JN6tg+EbiLCuVLpkmxOoG6sAi7Bb9uc=",
      "url": "_content/BlazorWasmPreRendering.Build/BlazorWasmPreRendering.Build.lfyg69o9wu.lib.module.js"
    },
    {
      "hash": "sha256-NgHobvE5wu6MFuX0QImF1lk8IP4UUN3UDirKa0WQVYc=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-TOPYwKltorv5iM1JqqzJayZWZx7LFnfSq2AhkWFNwrg=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-OaMAAd5n7ORfyur5e3QIyEVKJ76MKIvwbg7/icnnYcU=",
      "url": "_framework/Blazored.LocalStorage.12n6dz54qr.wasm"
    },
    {
      "hash": "sha256-aBQ/zgBY8QtcOXcb8G76IKsLIul3Y3HwMDb+wig6TzA=",
      "url": "_framework/Microsoft.AspNetCore.Components.0qg7s2at38.wasm"
    },
    {
      "hash": "sha256-Ux573peKEQ218Cy5jfERh3g4RoecVRs/uW6c5DeBAu4=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.lmcfcyebxn.wasm"
    },
    {
      "hash": "sha256-UMKuMN3hFIRfCZHEez4IdEUU+PNukdrMGeWuvWrJXPQ=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.gw4qjd2zm5.wasm"
    },
    {
      "hash": "sha256-nGjN8VdI0Lkaj97PcC7MpEghdOAAjwbcVjg4hpf4gdo=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.0zvz8tcuy8.wasm"
    },
    {
      "hash": "sha256-0mSQ7HXIZLJEBTFRfVY7zJAq1z5S7W7wIGYhgo3dgEk=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.6f3mqk4dod.wasm"
    },
    {
      "hash": "sha256-zvcr9DtzXsxH8BBocJ4EoYxfxToU4mpHwwKUUO3KLUM=",
      "url": "_framework/Microsoft.Extensions.Configuration.Binder.2vno1280fh.wasm"
    },
    {
      "hash": "sha256-i4UmIVmRYt9sXQYxprJFXFivAl11xAcf9azr6KH7EOw=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.j66pezmcjo.wasm"
    },
    {
      "hash": "sha256-A7TWrVcPF5z6+77e1AABovXnUVZ2NNAeGd8fD++uO4s=",
      "url": "_framework/Microsoft.Extensions.Configuration.dwrnjjov01.wasm"
    },
    {
      "hash": "sha256-2PxJ1s/1FHmNUIDSXh/IdWP7u+G5KyT9ESJ4TsAcGxA=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.cnmmfeokqg.wasm"
    },
    {
      "hash": "sha256-Ta3surCTEATmQUY4SQ/wpAIdyxK5fNnI4bm05ePwAsw=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.vdgbrs4or0.wasm"
    },
    {
      "hash": "sha256-tnMHqb6BpI1Jj9M9WNSAAJzzxHrQgov/aSXbFqc+xzk=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.ixsppbtym0.wasm"
    },
    {
      "hash": "sha256-6UgMJoVZBfDdfzYR0aKVK6BWArxpXC1qiQDDjiXw/L4=",
      "url": "_framework/Microsoft.Extensions.Localization.bvn14pws96.wasm"
    },
    {
      "hash": "sha256-qZTOMQMcbVMQtzbhwOIPzkI0YLkfLOGz6VQAgeEu6oE=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.pc62cfqh0g.wasm"
    },
    {
      "hash": "sha256-m2ci2/3UUoSj+LBjDg24wAVdJ7/OshaoahXtPt74ak4=",
      "url": "_framework/Microsoft.Extensions.Logging.dypcmt2k1c.wasm"
    },
    {
      "hash": "sha256-93pAYAommWPUnWivkfPryiWKh9Fd/Lj8WvDOvMfWfE0=",
      "url": "_framework/Microsoft.Extensions.Options.1qi9y3zpi7.wasm"
    },
    {
      "hash": "sha256-zPXs1ZxaGv/gjScqkSbos0m3HyxJufpF3haxdyuT0QA=",
      "url": "_framework/Microsoft.Extensions.Primitives.wdgxpgsqcr.wasm"
    },
    {
      "hash": "sha256-63bzxZLVvNOmTsso6iLrptxGmKBQh2HUIEGtPUrRPeQ=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.lsljofql11.wasm"
    },
    {
      "hash": "sha256-gs6UfXTMqRndXscw/E9MLDl6gagNO3gnrghLwrN7i14=",
      "url": "_framework/Microsoft.JSInterop.apnmspbbpu.wasm"
    },
    {
      "hash": "sha256-X9RHf5/gpXxLNZa0Cl8xZRT19uDFXCMha80+WkVmEiI=",
      "url": "_framework/MudBlazor.76kp28gxuu.wasm"
    },
    {
      "hash": "sha256-ybGRQUCPVWdTQmplUYdG2HU1aI9knJ/Ez776ThrfwOc=",
      "url": "_framework/MudBlazorGitHubPages.dbj4zduhtw.wasm"
    },
    {
      "hash": "sha256-RAGgcnZLvnsI6sUEdR59FrENIeJ9WCD8R0XpRTreqRc=",
      "url": "_framework/Serilog.8v6q4eew3x.wasm"
    },
    {
      "hash": "sha256-oaUyoVo2a89AwFRLViIDIdBnhpi17mAo03uxs1QLd2g=",
      "url": "_framework/Serilog.Sinks.BrowserConsole.x47anjwz3v.wasm"
    },
    {
      "hash": "sha256-SJdN/S7KbMXEi1zwoJKfST5Y7dsaE3e3YzZKjRhu3x0=",
      "url": "_framework/System.Collections.497wcw745f.wasm"
    },
    {
      "hash": "sha256-3hvKMeEZ2427bUrwb4BuAC98niFBmBfQVi7H5DGmN9o=",
      "url": "_framework/System.Collections.Concurrent.isiw1zf344.wasm"
    },
    {
      "hash": "sha256-yZG9am7EyfuP0+d9MwyQX+GJK4BVXHAvZ1RwglG/VoQ=",
      "url": "_framework/System.Collections.Immutable.jxowktchjn.wasm"
    },
    {
      "hash": "sha256-tptG8WXmOXmueFkJUXHRa4AVphnUmvz++F/3H5wtNNU=",
      "url": "_framework/System.Collections.NonGeneric.e3ptc19yer.wasm"
    },
    {
      "hash": "sha256-EqURoVCEc4CwZO1OO7uFtS79F8d1oTeaZOOt6WEjr44=",
      "url": "_framework/System.Collections.Specialized.q52clw574l.wasm"
    },
    {
      "hash": "sha256-JNR/o2tUFaDeOk9pghPZD2sAdWEKA2OUJ2ONln9UeD0=",
      "url": "_framework/System.ComponentModel.076m38u6l8.wasm"
    },
    {
      "hash": "sha256-0zPcU/SK7S/lH4xT+MvpZEz3WiNzE82scvs7NkAc68Q=",
      "url": "_framework/System.ComponentModel.Annotations.5ao9lxtnjx.wasm"
    },
    {
      "hash": "sha256-ecg1DAg+U+JKY3gJ25MJwpgY3/FTojp6Hj+9mroE5GY=",
      "url": "_framework/System.ComponentModel.Primitives.hiizc154md.wasm"
    },
    {
      "hash": "sha256-0SAWZhKTqtanIjLSBr33gejRyocCDZpU3oMd9cNtc4c=",
      "url": "_framework/System.ComponentModel.TypeConverter.r5u2acuk3x.wasm"
    },
    {
      "hash": "sha256-UvcRtsdIA/Mjrvcias0xJd/vMEkJK9pvJGEu2awDUd4=",
      "url": "_framework/System.Console.u93jk7h1j2.wasm"
    },
    {
      "hash": "sha256-uEVVMYx7abWgasKfPzSB6wOMoCpVEVv4EcEAOCa4ph0=",
      "url": "_framework/System.IO.Pipelines.0uhw8kopg1.wasm"
    },
    {
      "hash": "sha256-mvU4MWApfNLP4SxFWxIqlmDt9JBRe0D0NjmuFG1EDP4=",
      "url": "_framework/System.Linq.Expressions.mgtpx26dmq.wasm"
    },
    {
      "hash": "sha256-k3tOW5tP1Pg+p6X57n/GkCtUxPRN7703NYt/a8hyU18=",
      "url": "_framework/System.Linq.jgobntys58.wasm"
    },
    {
      "hash": "sha256-tCznIAaQdysSsBlri4JhpkOJQ4Nhsopc01TKAJP/ByY=",
      "url": "_framework/System.Memory.gxk30wm3qo.wasm"
    },
    {
      "hash": "sha256-IwGUdCFT/bTrVsSeM+GH+p7lNj/QctorMQ3XHOM4lus=",
      "url": "_framework/System.Net.Http.xjt5e7pw25.wasm"
    },
    {
      "hash": "sha256-nB5JS/nQn/pNhPGXYrb1uDoDn3cuo9TQKE1RKnVa648=",
      "url": "_framework/System.Net.Primitives.8x3nzqo64g.wasm"
    },
    {
      "hash": "sha256-wNfPvrHDu12m8nAsDGzNZQk23FT+Jj3h9Ewtkzk8Yuc=",
      "url": "_framework/System.ObjectModel.wgm2i2b0yp.wasm"
    },
    {
      "hash": "sha256-ZkaENvlbA1EYcDYmMv/agtzFWDvDmfEWPG0fkY/qk48=",
      "url": "_framework/System.Private.CoreLib.em8risez40.wasm"
    },
    {
      "hash": "sha256-zTueJvW+RqpYiUOMKNU1ePf/syIOhQTOhqx5jeDTy4k=",
      "url": "_framework/System.Private.Uri.5i8fnnbqx6.wasm"
    },
    {
      "hash": "sha256-mpqADt50XBKv0jfHL/pqKFHx+EiZ5JyoisOFgHWrrAY=",
      "url": "_framework/System.Runtime.2hwwtvyfxo.wasm"
    },
    {
      "hash": "sha256-t5fC5E2r9YJ+puOWw7YuXXMwvd7LxeR0Zt16THexNM0=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.zp9u3yqbi4.wasm"
    },
    {
      "hash": "sha256-KD5saNzkpUD3A/RXlqBthi/qKA3Sk2nZuNvyfL9+EWc=",
      "url": "_framework/System.Text.Encodings.Web.wmi2z5c0zd.wasm"
    },
    {
      "hash": "sha256-jK0VA824YDpoovuLVWk3TqAwHGUhz1S5SWtOaJ/+oEo=",
      "url": "_framework/System.Text.Json.ohlbs4ozh2.wasm"
    },
    {
      "hash": "sha256-p1r1IaXqJVx77+fmYIfU96tRTd4rwZCgnHY4J7JgRck=",
      "url": "_framework/System.Text.RegularExpressions.7ktsaz6zb1.wasm"
    },
    {
      "hash": "sha256-F5PSI/gBuwoWEF7SbdO7+2/Lo9hw0ISBKug8avOpxP0=",
      "url": "_framework/System.Threading.vuopdrx302.wasm"
    },
    {
      "hash": "sha256-v1DeJU321NUwk3KJ0Lf8lQA3zwRfrxNommmMBs1s3Gk=",
      "url": "_framework/System.f0fr8djds0.wasm"
    },
    {
      "hash": "sha256-+c/4XhmVdJAAeODwch7x6464rL8MKkPsQn4pxx3Ufyk=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-5TAd2is0AgjjYIAuEN8Bd5ZPoTk8dKE9RRtIQr4H5Lw=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-89jyB8DlCnV2BPMV477jOe1Sm0WXwVf8RuoSPsj4Ym8=",
      "url": "_framework/dotnet.native.3c4wvb350q.wasm"
    },
    {
      "hash": "sha256-LX9rFEWGVxhkOkAVPG0w5RxPwzPBlEUz6dQNjWS7M+M=",
      "url": "_framework/dotnet.native.hvg7u8bimp.js"
    },
    {
      "hash": "sha256-dCmS9Zx4egtLYSUgTI3R6gMS+Yg8MkzxW1CgEMJKAEw=",
      "url": "_framework/dotnet.runtime.cymp1amu5g.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-+A9GJSL1F7E2tMCpF5MhfSLW2Gd35PbafP4B4Z7MEcE=",
      "url": "appsettings.json"
    },
    {
      "hash": "sha256-yis2dNdJ6e9R472mcuwUOsxBPCQX3snSMmHAL3zu2D8=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-LV3+f00+twyg9GdkcdZgHL9eNsYya/KVnqdVOAG71Os=",
      "url": "index.html"
    },
    {
      "hash": "sha256-VSQRX1zufPPfljeh63jtX4Vvpz7IiZ3mWL3FRcPG7gM=",
      "url": "manifest.webmanifest"
    }
  ]
};
